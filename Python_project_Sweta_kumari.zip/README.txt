Steps to run the program:
1) install required modules
a) pip install flask
b) pip install pandas
c) pip install sklearn
d) pip install nltk
e) pip install preprocessing

2) unzip Python_project_Sweta_kumari.zip
3) cd MovieRecommendationApp
4) python moviereco.py
5) open url http://127.0.0.1:5000 in web browser
6) Enter movie name in input box to get movie suggestions

